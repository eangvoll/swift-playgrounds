//: Playground - noun: a place where people can play

import UIKit

func combineArrays(arr1:[Any], arr2:[Any]) -> [Any] {
    var resArr:[Any] = []
    let maxCount = arr1.count > arr2.count ? arr1.count : arr2.count
    for index in 0..<maxCount {
        if index < arr1.count {
            resArr.append(arr1[index])
        }
        if index < arr2.count {
            resArr.append(arr2[index])
        }
    }
    return resArr
}

func combineArraysWithInsert(arr1:[Any], arr2:[Any]) -> [Any] {
    var longArr:[Any] = arr1.count > arr2.count ? arr1 : arr2
    let shortArr:[Any] = arr1.count > arr2.count ? arr2 : arr1
    for index in 0..<shortArr.count {
        longArr.insert(shortArr[index], at: index*2)
    }
    return longArr
}
    


var arr2 = ["a","b","c","d"]
var arr1 = ["bo","ro","me","tr"]
var emptyArr:[Any] = []

print (combineArrays(arr1: arr1, arr2: arr2))
print (combineArraysWithInsert(arr1: arr1, arr2: arr2))
print (combineArraysWithInsert(arr1: emptyArr, arr2: arr2))
print (combineArraysWithInsert(arr1: arr1, arr2: emptyArr))











