//: Playground - noun: a place where people can play

import UIKit

var age = 30
var weight = 200

var milesRun = 56.45  // Inferred double

var someNum : Double =  23761416534153461547165347513
var milesRan = 56.45
var pi:Float = 3.14

// Arithmetic Operators
var area = 15 * 20
var sum = 5 + 6
var diff = 10 - 3
var div = 12/3
var div1 = 13/5   // Reminder is not provided
var reminder = 13%5
var result = "The result by 13/5 is \(div1) with reminder of \(reminder)"
var randomNumber = 13
if (randomNumber % 2 == 0) {
    print ("This is an even number")
} else {
    print ("This is an odd number")
}

print ("\(randomNumber) is an \(randomNumber % 2 == 0 ? "even" : "odd") number")

var result2 = 15 * ((5 + 7) / 3)




