//: Playground - noun: a place where people can play

import UIKit

func add(num1:Double, num2:Double) -> Double {
    return num1 + num2
}

func subTract(num1:Double, num2:Double) -> Double {
    return num1 - num2
}

