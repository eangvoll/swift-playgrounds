//: Playground - noun: a place where people can play

import UIKit

// Optionals : separates good code from bad, help prevent crashes
// 

var lotteryWinnings: Int?  // This may or may not have a value


// First rule : Dont ever, ever implicitly unwrap an optional variable!!!!!!
// like this: print (lotteryWinnings!)  Will crash!


// Correct :
if lotteryWinnings != nil {
    print(lotteryWinnings!)
}

// ALWAYS CHECK!

// another way is (preferred way)
if let winnings = lotteryWinnings {
    print (winnings)
}

class Car {
    var model: String?
}

var vehicle : Car?


vehicle = Car()
vehicle?.model = "Bronco"

if let v = vehicle, let m = v.model {
    print(m)
}


var cars: [Car]?
cars = [Car]()

if let carArr = cars, carArr.count > 0 {
    // only execute if not nil and count is not zero
}


class Person {
    private var _age: Int!
    
    var age: Int {
        if _age == nil {
            _age = 15
        }
        return _age
    }
    
    
    
    func setAge(newAge: Int) {
        self._age = newAge
    }
}


var jack = Person()



class Dog {
    var species:String
    
    
    init (specie:String) {
        species = specie
    }
    
    init () {
        species = "Not set"
    }
}


