//: Playground - noun: a place where people can play

import UIKit

var amITheBestTeacherEver = true
amITheBestTeacherEver = false

