//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


var namesOfIntegers = [Int:String]()

namesOfIntegers[3] = "Three"
namesOfIntegers[44] = "Fortyfour"

var airports: [String:String] = ["YYZ":"Toronto pearson", "LAX":"Los Angeles International"]
print("The airports dictionsry has \(airports.count) items")

if !airports.isEmpty {
    "The airports dictionary is not empty"
}

airports["LHR"] = "London"
airports["LHR"] = "London Heathtrow"
airports["DEV"] = "Devslopes Internationals"
print("The airports dictionsry has \(airports.count) items")
airports["DEV"] = nil
print("The airports dictionsry has \(airports.count) items")

for (airportCode, airportName) in airports {
    print ("\(airportCode) is \(airportName)")
}

for key in airports.keys {
    print ("Key : \(key)")
}

for value in airports.values {
    print ("value : \(value)")
}


var arr:[String] = []
var arrDouble:[Double] = [1.2, 1, 4, 4.67]
var arr3 = ["test","espen","angvoll"]
arr3.append("ny")



