

class Node <T>:CustomStringConvertible {

    var value:T
    var children : [Node] = []
    weak var parent: Node?
    
    var description:String {
        var text = "\(value)"
        
        
        if !children.isEmpty {
            text += " {" + children.map {$0.description }.joined(separator: ", ") + "} "
            
//            text += " {"
//            for child in children {
//                if children.last?.value != child.value {
//                    text += child.description + ", "
//                } else {
//                    text += child.description
//                }
//            }
//            text += " }"
        }
        return text
    }
    
    init (value:T) {
        self.value = value
    }
    
    
    func add(child:Node) {
        children.append(child)
        child.parent = self
    }
}


extension Node where T: Equatable {


    func search (value:T) -> Node? {
        if value == self.value {
            return self
        }
        
        for child in children {
            if let found = child.search(value: value) {
                return found
            }
        }
        
        return nil
    }
}


let beverages = Node(value: "beverages")
let hotBeverages = Node(value:"hot")
let coldBeverages = Node(value:"cold")

beverages.add(child: hotBeverages)
beverages.add(child: coldBeverages)

let tea = Node(value: "Tea")
tea.add(child: Node(value: "black"))
tea.add(child: Node(value: "green"))
tea.add(child: Node(value: "chai"))
hotBeverages.add(child: tea)
hotBeverages.add(child: Node(value: "coffee"))
hotBeverages.add(child: Node(value: "cocoa"))

let soda = Node(value: "soda")
soda.add(child: Node(value: "ginger ale"))
soda.add(child: Node(value: "bitter lemon"))
coldBeverages.add(child: soda)
coldBeverages.add(child: Node(value: "milk"))


print(beverages)



let number = Node(value: "5")
number.add(child:Node(value: "dette er en test"))



public indirect enum BinaryTree<T> {
    case node(BinaryTree<T>, T, BinaryTree<T>)
    case empty
}










