//: Playground - noun: a place where people can play

import UIKit

let allowedEntry = false


// Logical NOT operator - unary prefix operator
if !allowedEntry {
    print ("ACCESS DENIED!")
}


let enteredDoorCode = true
let passedRetinaScan = false
let IAmTomCruiseFromMissionImposssible = true

if enteredDoorCode && passedRetinaScan || IAmTomCruiseFromMissionImposssible {
    print ("Welcome")
} else {
    print ("ACCESS DENIED!")
}



