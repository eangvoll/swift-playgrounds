class Person {
    
    var age: Int!
    
    func setAge(newGae:Int) {
        age = newGae
    }
    
}


print (Person().age)


class Dog {
    var species:String

    init (spec:String ) {
        species = spec
    }
}

var d = Dog(spec: "Dog")
print (d.species)



