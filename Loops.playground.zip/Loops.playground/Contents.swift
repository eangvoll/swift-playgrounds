//: Playground - noun: a place where people can play

import UIKit

var salaries = [45000.0, 100000.0, 54000.0, 20000.0]
var x = 0

repeat {
    salaries[x] = salaries[x] + (salaries[x] * 0.10)
    x = x + 1
} while (x < salaries.count)

print (salaries)

for i in 0..<salaries.count {
    salaries[i] = salaries[i] + (salaries[i] * 0.10)
}


for y in 1...5 {
    print ("y = \(y)")
}
for y2 in 1..<5 {
    print ("y2 = \(y2)")
}


for salary in salaries {
    print ("Salary : \(salary)")
}
