//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
var length = 5
var width = 10
var area = length * width


var bankAccountBalance = 500.00
var reebookAlienStomper = 350.00

func purchaseItem (currentBankAccount: inout Double, itemPrice:Double) {
    if itemPrice <= currentBankAccount {
        currentBankAccount = currentBankAccount - itemPrice
        print ("Purchased item for: $\(itemPrice)")
    } else {
        print ("You are broke.  You should learn how to save money!")
    }
}


purchaseItem(currentBankAccount: &bankAccountBalance, itemPrice: reebookAlienStomper)
