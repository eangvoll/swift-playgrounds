//: Playground - noun: a place where people can play

import UIKit

// Inferred string
var str = "Hello, playground"

// explicit string
var str2:String = "Hello, playground"


var firstName = "Jack"
var lastName = "Bauer"

var age = 45
var fullName = firstName + " " + lastName
var fullName2 = "\(firstName) \(lastName) is \(age)"  //String interpolation
fullName.append(" III")

var bookTitle = "Revenge of the crabcake"
bookTitle = bookTitle.capitalized

var chatroomAnnoyingCapsGuy = "PLEASE HELP ME NOW; HERE IS MY 100 LINES OF CODE!"
var lowercasedChat = chatroomAnnoyingCapsGuy.lowercased()

var sentence = "What the fetch? Heck that is crazy"
if sentence.contains("fetch") || sentence.contains("heck") {
    sentence.replacingOccurrences(of: "fetch", with: "tuna")
    sentence.replacingOccurrences(of: "Heck", with: "Playa")
    
}

